package com.capgemini.ars.service;

import java.util.List;

import com.capgemini.ars.dao.BookingDao;
import com.capgemini.ars.dao.BookingDaoImpl;
import com.capgemini.ars.dto.Booking;
import com.capgemini.ars.dto.Passenger;

public class BookingServiceImpl implements BookingService 
{
	BookingDao bookingDao = new BookingDaoImpl();
	@Override
	public long addBooking(Booking bookFlight, List<Passenger> passengerList) 
	{
		return bookingDao.addBooking(bookFlight, passengerList);
		
	}

	@Override
	public List<Passenger> viewPassesnger(String flightNo) {
		
		System.out.println(flightNo);
		return bookingDao.viewPassesnger(flightNo);
	}
	@Override
	public String getPassesnger(String flightNo) {
		// TODO Auto-generated method stub
		return bookingDao.getPassesnger(flightNo);
	}
}
