package com.capgemini.ars.service;

import com.capgemini.ars.dao.UsersDao;
import com.capgemini.ars.dao.UsersDaoImpl;
import com.capgemini.ars.dto.Users;


public class UsersServiceImpl implements UsersService{

	private UsersDao userDao;
	public UsersServiceImpl() {
		userDao = new UsersDaoImpl();
	}
	@Override
	public boolean validateUser(Users user) {
		
		return userDao.validateUser(user);
	}
	
	@Override
	public void addUser(Users user) {
		userDao.addUser(user);
		
	}
	@Override
	public void updateUser(Users user){
		//System.out.println("in user update service...");
		userDao.updateUser(user);
		
	}

	@Override
	public Users searchUser(Users user){
		//System.out.println(" in user service search.... ");
		//userdao.searchUser(user);
		System.out.println(user);
	
		return userDao.searchUser(user);
	}
}
