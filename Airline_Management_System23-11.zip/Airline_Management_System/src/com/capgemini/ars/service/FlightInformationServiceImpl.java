package com.capgemini.ars.service;

import java.util.List;

import com.capgemini.ars.dao.FlightInformationDao;
import com.capgemini.ars.dao.FlightInformationDaoImpl;
import com.capgemini.ars.dto.FlightInformation;

public class FlightInformationServiceImpl implements FlightInformationService{

	private  FlightInformationDao flightInfoDao;
	public FlightInformationServiceImpl() {
		flightInfoDao = new FlightInformationDaoImpl();
	}
	@Override
	public void addFlight(FlightInformation flightInfo) {
		flightInfoDao.addFlight(flightInfo);
		
	}
	@Override
	public List<String> fetchFlightNumber() {
		return flightInfoDao.fetchFlightNumber();
	}
	@Override
	public FlightInformation fetchFlightDetails(String flightNo) {
		
		return flightInfoDao.fetchFlightDetails(flightNo);
	}
	@Override
	public void updateFlightDetails(FlightInformation flightInfo, String oldFlightNumber) {
		
		flightInfoDao.updateFlightInformation(flightInfo, oldFlightNumber);
	}
	@Override
	public List<String> getDestination() {
		return flightInfoDao.getDestination();
	}
	@Override
	public List<FlightInformation> viewFlightDetails(String flightDate,
			String destinationValue) {
		
		return flightInfoDao.viewFlightDetails(flightDate, destinationValue);
	}
	@Override
	public List<FlightInformation> searchFlight(FlightInformation flightInfo) {
		
		return flightInfoDao.searchFlight(flightInfo);
	}
	
	@Override
	public List<FlightInformation> getSourceDestination() {
		// TODO Auto-generated method stub
		return flightInfoDao.getSourceDestination();
	}

}
