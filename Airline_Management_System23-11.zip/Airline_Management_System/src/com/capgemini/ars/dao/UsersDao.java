package com.capgemini.ars.dao;

import com.capgemini.ars.dto.Users;



public interface UsersDao {

	boolean validateUser(Users user);
	void addUser(Users user);
	public void updateUser(Users user);
	public Users searchUser(Users user);
}
