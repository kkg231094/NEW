package com.capgemini.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.capgemini.ars.dto.Booking;
import com.capgemini.ars.dto.Passenger;
import com.capgemini.ars.factory.DBUtil;

public class BookingDaoImpl implements BookingDao
{

	@Override
	public long addBooking(Booking bookFlight, List<Passenger> passengerList) 
	{
		System.out.println("In dao booking");
		Random rand = new Random();
		long  n = rand.nextInt(500000) + 1;
		System.out.println(n);
		try (Connection conn = DBUtil.getConnection()){
			
			String bookingId = ""+n;
			System.out.println(bookingId);
			String queryBook = "INSERT into Booking_Information values (?,?,?,?,?,?,?,?,?)";
			PreparedStatement pstm = conn.prepareStatement(queryBook);
			pstm.setString(1, bookingId);
			pstm.setString(2, bookFlight.getCustEmail());
			pstm.setDouble(3, bookFlight.getNoOfPassengers());
			pstm.setString(4, bookFlight.getClassType());
			pstm.setDouble(5, bookFlight.getTotalFare());
			pstm.setString(6, bookFlight.getSeatNumber());
			pstm.setString(7, bookFlight.getCreditCardInfo());
			pstm.setString(8, bookFlight.getSrcCity());
			pstm.setString(9, bookFlight.getDestCity());
			int status = pstm.executeUpdate();
			System.out.println(status);
			if(status!=0)
				addPassengers(bookingId, passengerList);
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(n);
		return n;
	}
	
	public void addPassengers(String bookingId, List<Passenger> passengerList)
	{
		try (Connection conn = DBUtil.getConnection()){
			
			for(Passenger p: passengerList)
			{
				String queryAddPassenger = "INSERT into passenger_list values(?,?,?,?,?,?)";
				PreparedStatement pstm = conn.prepareStatement(queryAddPassenger);
				pstm.setString(1, bookingId);
				pstm.setString(2, p.getName());
				pstm.setString(3, p.getAge());
				pstm.setString(4, p.getGender());
				pstm.setString(5, p.getEmail());
				pstm.setString(6, p.getFlightnumber());
				pstm.executeUpdate();
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Override
	public List<Passenger> viewPassesnger(String flightNo) {
		
		System.out.println("In DAO++++ "+flightNo);
		List<Passenger> pass = new ArrayList<Passenger>();
		String sqlViewPass = "SELECT * from passenger_list WHERE FLIGHT_NUM=?";
		try (Connection conn = DBUtil.getConnection()){
			
			PreparedStatement pstm = conn.prepareStatement(sqlViewPass);
			
			pstm.setString(1, flightNo);
			ResultSet res = pstm.executeQuery();
			
			while(res.next()){
				Passenger passenger = new Passenger();
				passenger.setBookingId(res.getString(1));
				passenger.setName(res.getString(2));
				passenger.setAge(res.getString(3));
				passenger.setGender(res.getString(4));
				passenger.setEmail(res.getString(5));
				passenger.setFlightnumber(flightNo);
				System.out.println(passenger);
				pass.add(passenger);
			}
					
		} catch (Exception e) {
			// TODO: handle exception
		}
		return pass;
	}
	
	@Override
	public String getPassesnger(String flightNo) {
		
		String sqlPassesnger = "SELECT count(flight_num) FROM passenger_list WHERE flight_num=?";
		String p=null;
		try (Connection conn = DBUtil.getConnection()){
			
			PreparedStatement pstm = conn.prepareStatement(sqlPassesnger);
			pstm.setString(1, flightNo);
			
			ResultSet res = pstm.executeQuery();
			while(res.next()){
				
				 
				  p = res.getString(1);
			}
			
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return p;
	}

	
}
