package com.capgemini.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;




import java.sql.ResultSet;

import org.jboss.security.auth.spi.Users.User;

import com.capgemini.ars.dto.Users;
import com.capgemini.ars.factory.DBUtil;

public class UsersDaoImpl implements UsersDao{

	@Override
	public boolean validateUser(Users user) {
		String sqlValid = "SELECT * FROM users WHERE username=? AND password=?";
		try(Connection conn = DBUtil.getConnection()) {
			
			PreparedStatement pstm = conn.prepareStatement(sqlValid);
			
			pstm.setString(1, user.getUserName());
			pstm.setString(2, user.getPassword());
			
			ResultSet res = pstm.executeQuery();
			while(res.next()){
				
				user.setRole(res.getString("role"));
				
				
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}

	@Override
	public void addUser(Users user) {
		String sqlInsert = "INSERT INTO users VALUES(?,?,?,?,?)";
		
		try (Connection conn = DBUtil.getConnection()){
			
			PreparedStatement pstm = conn.prepareStatement(sqlInsert);
			
			pstm.setString(1, user.getName());
			pstm.setString(2, user.getUserName());
			pstm.setString(3,user.getPassword());
			pstm.setString(4, "user");
			pstm.setLong(5, user.getMobileNum());
			
			pstm.executeUpdate();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	@Override
	public void updateUser(Users user){
		
		
		//System.out.println(" in update user DAO....");
			try(Connection con = DBUtil.getConnection()){
			String query = "update users set  password = ?, mobile_no = ?  where username = ? ";
			PreparedStatement pstm = con.prepareStatement(query);
			pstm.setString(1, user.getPassword());
			pstm.setLong(2, user.getMobileNum());
			pstm.setString(3, user.getUserName());

			int i=pstm.executeUpdate();
			//System.out.println(i);
			}catch (Exception e) {
				e.printStackTrace();
			}		
	}

	@Override
	public Users searchUser(Users user) {
		
		
		//System.out.println(" in search user DAO....");
		Users user_detail=new Users ();
			try(Connection con = DBUtil.getConnection()){
			String query = "select username,password,mobile_no from users where username=?";
			PreparedStatement pstm = con.prepareStatement(query);
			System.out.println(user.getUserName());
			pstm.setString(1,user.getUserName());
			ResultSet rs = pstm.executeQuery();
			System.out.println("search done.........");
			
			
			while (rs.next()) {
				user_detail.setUserName(rs.getString("username"));
				user_detail.setPassword(rs.getString("password"));
				user_detail.setMobileNum(rs.getLong("mobile_no"));
				System.out.println(user_detail);
				break;
			
			}
			}catch (Exception e) {
				e.printStackTrace();
			}	
		return user_detail;
		
		
	
	}
}
