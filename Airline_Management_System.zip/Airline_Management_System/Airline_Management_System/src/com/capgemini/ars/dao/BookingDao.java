package com.capgemini.ars.dao;

import java.util.List;

import com.capgemini.ars.dto.Booking;
import com.capgemini.ars.dto.Passenger;

public interface BookingDao 
{
	
	public long addBooking(Booking bookFlight, List<Passenger> passengerList);
	public List<Passenger> viewPassesnger(String flightNo);
	public String getPassesnger(String flightNo);
}
