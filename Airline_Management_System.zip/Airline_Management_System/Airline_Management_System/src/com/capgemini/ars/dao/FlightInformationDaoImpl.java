package com.capgemini.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.capgemini.ars.dto.FlightInformation;
import com.capgemini.ars.factory.DBUtil;


public class FlightInformationDaoImpl implements FlightInformationDao{

	
	@Override
	public void addFlight(FlightInformation flightInfo) {
		
		try (Connection conn = DBUtil.getConnection()){
			String queryAdd = "INSERT INTO FlightInformation VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
			
			PreparedStatement pstm = conn.prepareStatement(queryAdd);
			pstm.setString(1, flightInfo.getFlightNumber());
			pstm.setString(2, flightInfo.getFlightAirline());
			pstm.setString(3, flightInfo.getDepartureCity());
			pstm.setString(4, flightInfo.getArrivalCity());
			
			java.sql.Date parseDeparture = toSQLDate(flightInfo.getDepartureDate());
			java.sql.Date parseArrival = toSQLDate(flightInfo.getArrivalDate());
			
			//java.sql.Date dateDeparture = new java.sql.Date(parseDeparture.getTime());
			//java.sql.Date dateArrival = new java.sql.Date(parseArrival.getTime());
			
			pstm.setDate(5, parseDeparture);
			pstm.setDate(6, parseArrival);
			pstm.setString(7, flightInfo.getDepartureTime());
			pstm.setString(8, flightInfo.getArrivalTime());
			pstm.setString(9, flightInfo.getFirstSeat());
			pstm.setDouble(10, flightInfo.getFirstSeatFare());
			pstm.setString(11, flightInfo.getBusinessSeat());
			pstm.setDouble(12, flightInfo.getBusinessSeatFare());
		
			int status = pstm.executeUpdate();
			
			if(status == 1){
				System.out.println("Inserted");
			}else{
				System.out.println("Not Inserted");
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public List<String> fetchFlightNumber() {
		List<String> myList = new ArrayList<>();
		try (Connection conn = DBUtil.getConnection()){
			
			String queryFetch = "SELECT flightno FROM FlightInformation";
			
			PreparedStatement pstm = conn.prepareStatement(queryFetch);
			
			
			ResultSet res = pstm.executeQuery();
			
			int count = 1;
			while(res.next()){
				 myList.add(res.getString(1));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return myList;
	}

	@Override
	public FlightInformation fetchFlightDetails(String flightNo) {
		FlightInformation flightInfo = new FlightInformation();
		try (Connection conn = DBUtil.getConnection()){
			
			String queryUpdate = "SELECT * FROM FlightInformation WHERE flightno=?";
			
			PreparedStatement pstm = conn.prepareStatement(queryUpdate);
	
			pstm.setString(1, flightNo);
			
			ResultSet res = pstm.executeQuery();
			
			while(res.next()){
				flightInfo.setFlightNumber(flightNo);
				flightInfo.setFlightAirline(res.getString(2));
				flightInfo.setDepartureCity(res.getString(3));
				flightInfo.setArrivalCity(res.getString(4));
				
				java.util.Date newDate = res.getTimestamp(5);
				DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
				String departDate = df.format(newDate);
				
				java.util.Date newDate1 = res.getTimestamp(6);
				String arriveDate = df.format(newDate1);
				
				flightInfo.setDepartureDate(departDate);
				flightInfo.setArrivalDate(arriveDate);
				flightInfo.setDepartureTime(res.getString(7));
				flightInfo.setArrivalTime(res.getString(8));
				flightInfo.setFirstSeat(res.getString(9));
				flightInfo.setFirstSeatFare(res.getDouble(10));
				flightInfo.setBusinessSeat(res.getString(11));
				flightInfo.setBusinessSeatFare(res.getDouble(12));
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flightInfo;
	}

	@Override
	public void updateFlightInformation(FlightInformation flightInfo, String oldFlightNumber) {
		
		try (Connection conn = DBUtil.getConnection()){
			
			String queryUpdateDetails = "UPDATE FlightInformation SET flightno=?,airline=?,dep_city=?,arr_city=?,dep_date=?,arr_date=?,dep_time=?,arr_time=?,FirstSeats=?,FirstSeatFare=?,BussSeats=?,BussSeatsFare=? WHERE flightno=?";
			
			PreparedStatement pstm = conn.prepareStatement(queryUpdateDetails);
			
			pstm.setString(1, flightInfo.getFlightNumber());
			pstm.setString(2, flightInfo.getFlightAirline());
			pstm.setString(3, flightInfo.getDepartureCity());
			pstm.setString(4, flightInfo.getArrivalCity());
			
			Date parseDeparture = toSQLDate(flightInfo.getDepartureDate());
			Date parseArrival = toSQLDate(flightInfo.getArrivalDate());
			
			java.sql.Date dateDeparture = new java.sql.Date(parseDeparture.getTime());
			java.sql.Date dateArrival = new java.sql.Date(parseArrival.getTime());
			pstm.setDate(5, dateDeparture);
			pstm.setDate(6, dateArrival);
			pstm.setString(7, flightInfo.getDepartureTime());
			pstm.setString(8, flightInfo.getArrivalTime());
			pstm.setString(9, flightInfo.getFirstSeat());
			pstm.setDouble(10, flightInfo.getFirstSeatFare());
			pstm.setString(11, flightInfo.getBusinessSeat());
			pstm.setDouble(12, flightInfo.getBusinessSeatFare());
			
			pstm.setString(13, oldFlightNumber);
			System.out.println(oldFlightNumber);
			
			int status = pstm.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	public List<String> getDestination(){
		
		String sqlDestination = "SELECT DISTINCT arr_city FROM flightinformation";
		List<String> destinationList = new ArrayList<>();
		try (Connection conn = DBUtil.getConnection()){
			PreparedStatement ptmt = conn.prepareStatement(sqlDestination);
			
			ResultSet rs = ptmt.executeQuery();
			while(rs.next())
			{
				destinationList.add(rs.getString(1));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return destinationList;
		
	}

	@Override
	public List<FlightInformation> viewFlightDetails(String flightDate,
			String destinationValue) 
	{
		String sqlView = "SELECT * FROM flightinformation WHERE arr_city=? AND dep_date=?";
		java.sql.Date deptDate = toSQLDate(flightDate);
		List<FlightInformation> viewFlightList = new ArrayList<>();
		try(Connection conn = DBUtil.getConnection())
		{
			PreparedStatement pstm = conn.prepareStatement(sqlView);
			pstm.setString(1, destinationValue);
			pstm.setDate(2, deptDate);
			ResultSet res = pstm.executeQuery();
			while(res.next())
			{
				FlightInformation viewFlightInfo = new FlightInformation();
				viewFlightInfo.setFlightNumber(res.getString(1));
				viewFlightInfo.setFlightAirline(res.getString(2));
				viewFlightInfo.setDepartureCity(res.getString(3));
				viewFlightInfo.setArrivalCity(res.getString(4));
				
				java.util.Date newDate = res.getTimestamp(5);
				DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
				String departDate = df.format(newDate);
				
				java.util.Date newDate1 = res.getTimestamp(6);
				String arriveDate = df.format(newDate1);
				
				viewFlightInfo.setDepartureDate(departDate);
				viewFlightInfo.setArrivalDate(arriveDate);
				viewFlightInfo.setDepartureTime(res.getString(7));
				viewFlightInfo.setArrivalTime(res.getString(8));
				viewFlightInfo.setFirstSeat(res.getString(9));
				viewFlightInfo.setFirstSeatFare(res.getDouble(10));
				viewFlightInfo.setBusinessSeat(res.getString(11));
				viewFlightInfo.setBusinessSeatFare(res.getDouble(12));
				//System.out.println(viewFlightInfo);
				viewFlightList.add(viewFlightInfo);
			}
		}catch (Exception e) {
			// TODO: handle exception
		}
		return viewFlightList;
		
	}
	
	public java.sql.Date toSQLDate(String date)
	{
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Date parsed;
		java.sql.Date parsedDate = null;
		
		try {
			parsed = formatter.parse(date);
			parsedDate = new java.sql.Date(parsed.getTime());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return parsedDate;
	}

	@Override
	public List<FlightInformation> searchFlight(FlightInformation flightInfo) {

		String sqlView = "SELECT * FROM flightinformation WHERE  dep_city=? AND arr_city=? AND dep_date=?";
		
		java.sql.Date departureDate = toSQLDate(flightInfo.getDepartureDate());
		
		List<FlightInformation> viewFlightList = new ArrayList<>();
		try(Connection conn = DBUtil.getConnection())
		{
			PreparedStatement pstm = conn.prepareStatement(sqlView);
			pstm.setString(2, flightInfo.getArrivalCity());
			pstm.setString(1,flightInfo.getDepartureCity());
			pstm.setDate(3,departureDate );
			
			ResultSet res = pstm.executeQuery();
			
			while(res.next())
			{
				FlightInformation viewFlightInfo = new FlightInformation();
				viewFlightInfo.setFlightNumber(res.getString(1));
				viewFlightInfo.setFlightAirline(res.getString(2));
				viewFlightInfo.setDepartureCity(res.getString(3));
				viewFlightInfo.setArrivalCity(res.getString(4));
				
				java.util.Date newDate = res.getTimestamp(5);
				DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
				String departDate = df.format(newDate);
				
				java.util.Date newDate1 = res.getTimestamp(6);
				String arriveDate = df.format(newDate1);
				
				viewFlightInfo.setDepartureDate(departDate);
				viewFlightInfo.setArrivalDate(arriveDate);
				viewFlightInfo.setDepartureTime(res.getString(7));
				viewFlightInfo.setArrivalTime(res.getString(8));
				viewFlightInfo.setFirstSeat(res.getString(9));
				viewFlightInfo.setFirstSeatFare(res.getDouble(10));
				viewFlightInfo.setBusinessSeat(res.getString(11));
				viewFlightInfo.setBusinessSeatFare(res.getDouble(12));
				//System.out.println(viewFlightInfo);
				viewFlightList.add(viewFlightInfo);
				System.out.println("gfd"+viewFlightList);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return viewFlightList;
		
	}
	
	@Override
	public List<FlightInformation> getSourceDestination() {
		String sqlDestination = "SELECT DISTINCT arr_city, dep_city FROM flightinformation";
		List<FlightInformation> list = new ArrayList<>();
		try (Connection conn = DBUtil.getConnection()){
			PreparedStatement ptmt = conn.prepareStatement(sqlDestination);
			
			ResultSet rs = ptmt.executeQuery();
			while(rs.next())
			{
				FlightInformation flight = new FlightInformation();
				flight.setArrivalCity(rs.getString(1));
				flight.setDepartureCity(rs.getString(2));
				list.add(flight);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
		
	}
	
	

}
